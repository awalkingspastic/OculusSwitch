# OculusSwitch


App is intended to switch on and off Oculus Services.



When triggered "off" the HMD will not trigger Oculus Home to turn on

When triggered "on" the HMD will allow Oculus Home to be opened.



App must be run at 'Admin' privileges to work.


Close any instances of this app, right click the app and choose 
'Run This Program As an Administrator'.
App will be opened in system tray.


Right click with mouse to choose options.

Easy acess to turn on/off color coded to green/red for visual affect.
